# -*- coding: utf-8 -*-
def classFactory(iface):
    from .showextent import ShowExtent
    return ShowExtent(iface)
