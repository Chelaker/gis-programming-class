# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtCore import QObject
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon

class ShowExtent(QObject):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), "Show Extent", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        del self.action

    def run(self):
        layer = self.iface.activeLayer()
        if not layer or layer.type() != layer.VectorLayer:
            QMessageBox.information(self.iface.mainWindow(), "Show Extent", "Выберите активный векторный слой.")
            return
        ext = layer.extent()
        msg = f"Xmin: {ext.xMinimum()}\nXmax: {ext.xMaximum()}\nYmin: {ext.yMinimum()}\nYmax: {ext.yMaximum()}"
        QMessageBox.information(self.iface.mainWindow(), "Show Extent", msg)
